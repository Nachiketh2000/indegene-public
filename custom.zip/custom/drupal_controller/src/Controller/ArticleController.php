<?php

namespace Drupal\drupalup_controller\Controller;
use Drupal\Code\Datbase\Database;
use \Drupal\node\Entity\NodeType;
use Drupal\user\Entity\User;

class ArticleController {

    public function page() {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
        CURL_setopt($curl, CURLOPT_URL, 'http://worldtimeapi.org/api/timezone/Asia/Kolkata');
        $res = curl_exec($curl); 
        curl_close($curl); 
        $result=json_decode($res); 
        $first = $result->datetime;        
        
        //insert the result into database
        $query =\Drupal::database()->insert('time');
        $query->fields(['time' => $first]);
        $query->execute();

        //retrive the nodes in ascending order
        $star = \Drupal::entityQuery('node')
          ->condition('title',1,'>')
          ->sort('title', 'ASC')
          ->accessCheck(True);
        $results =$star->execute();
        dsm($results);

        //retrive the first name of the user and arrange in descending order
        $moon = \Drupal::entityQuery('user')
          ->condition('field_first_name',1,'>')
          ->sort('field_first_name','DESC')
          ->accessCheck(True);
        $solution =$moon->execute();
        dsm($solution);

        return array(
          '#theme' => 'article_list',
          '#items' => $first ,
          '#title' => 'Date and time'
        );

    }
  }


?>
